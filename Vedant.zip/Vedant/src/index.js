import React, { Component } from 'react';
import { render } from 'react-dom';
import Hello from './Hello';
import './style.css';

class Project extends Component {
  constructor() {
    super();
    this.state = {
      search_keyword: 'reactjs',
      list_of_videos: [],
      loading_status: null ,
      current_video_url: '',
      comment: '',
      list_of_comments: [],
      like_status: 'Like',
      is_loading_error: false
    };
  }
setSearchValue = (event) => {

this.setState({
  search_keyword: event.target.value
})
console.log(this.state.search_keyword)
}
searchVideo = async () => {
    this.setState({
    loading_status: "LOADING",
    is_loading_error: false
  })
const response = await fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=15&order=viewCount&q=${this.state.search_keyword}&type=video&videoDefinition=high&key=AIzaSyDAyYIU0uRJadfSwFyYvrEhv86RfTGuqnM`);
const myJson = await response.json();
console.log("myJson " , myJson);
if(myJson.items.length == 0) {
  this.setState({
    is_loading_error: true
  })
}
this.setState({
  list_of_videos: myJson.items
})
console.log(this.state.list_of_videos)
  this.setState({
    loading_status: "LOADED"
  })
}
showMostPopularVideos = async () => {
  this.setState({
    loading_status: 'LOADING'
  })
  const response = await fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&chart=mostPopular&maxResults=15&regionCode=IN&key=AIzaSyDAyYIU0uRJadfSwFyYvrEhv86RfTGuqnM`);
const myJson = await response.json();
console.log("myJson " , myJson);
this.setState({
  list_of_videos: myJson.items,
  loading_status: "LOADED"
})
console.log(this.state.list_of_videos)
this.setState({
  current_video_url: this.state.list_of_videos[0].id.videoId
})
console.log("current_video_url" , this.state.current_video_url)
}
componentDidMount() {
  this.showMostPopularVideos()
  console.log("list_of_videos" , this.state.list_of_videos)
}
setCurrentUrl = (id) => {

  this.setState({
    current_video_url: id
  })
}
setComment = (event) => {
  this.setState({
    comment: event.target.value
  })
}
addComment = () => {
  this.setState({
    list_of_comments: [...this.state.list_of_comments, this.state.comment],
    comment: ''
  })
}
likeButton = () => {
  if(this.state.like_status == "Like"){
  this.setState({
    like_status: 'Liked'
  })
  } else {
      this.setState({
    like_status: 'Like'
  })
  }

}
  render() {
    let videos = this.state.list_of_videos.map(eachVideo => (
<img src={eachVideo.snippet.thumbnails.high.url} style={{ height: '300px', cursor:'pointer'}} onClick={()=> this.setCurrentUrl(eachVideo.id.videoId)} />
        ))
    return (
    
      <div >
        <input  style={{ marginLeft:"450px",width:"430px"}} placeholder="Search here..." onChange={this.setSearchValue} />
        <button style={{marginLeft:"20px",width:'100px',backgroundColor:'#E6FA33'}} onClick={this.searchVideo}>Search</button>
        <br/>
      <div>
      <hr/>
      
{this.state.is_loading_error ? (<h1>No search found</h1>): (
  <iframe src={`https://www.youtube.com/embed/${this.state.current_video_url}`} style={{height: '600px', width: '1000px', float : 'left'}}/>
)}


      </div>
      <br/>
     
        <br/>
        <br/>
        <br/>
        <div style={{width: '450px', float : 'right'}}>
        {this.state.loading_status == "LOADING" ? (<h1>Loading...</h1>) : (videos) }
        </div>
         <div style={{display: 'block', float: 'left'}}>
    
{this.state.list_of_comments.map(eachComment => (
  <li>{eachComment}</li>
))}
         <h2> Comments</h2>
    <input style ={{outline: 0 ,border: '10',
    border: '1px solid #484a56',width:'200px',height:'25px'}} onChange={this.setComment} placeholder= "Your Name" value={this.state.comment}/>

    <input  style ={{outline: 0,
    border: '10',
    border: '1px solid #484a56',
    marginLeft:"45px", width:'200px',height:'25px'}}onChange={this.setComment} placeholder="Your Comment" value={this.state.comment}/> <br/>
    <button  style={{marginLeft:"30px",height:'30px',borderRadius:'5px',backgroundColor:'#1EED17'}}onClick={this.addComment}> Comment</button>
    <button  style={ {marginLeft: "50px", marginTop:'5px' ,padding:'12px',borderRadius:'5px',backgroundColor:'#6EC3CD'}}onClick={this.likeButton}>{this.state.like_status}</button>
   
    
    


      </div>
      </div>
    );
  } 
}

render(<Project />, document.getElementById('root'));